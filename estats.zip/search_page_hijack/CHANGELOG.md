## [1.3.0] - May 11th, 2020

Thanks to [@obrunsmann](https://github.com/obrunsmann) for this release.

- Added `showItemsOnEmpty` parameter.

## [1.2.0] - April 30th, 2020

Thanks to [@i62lucoc](https://github.com/i62lucoc) for the feedback.

- Added `itemStartsWith` parameter.
- Added `itemEndsWith` parameter.

## [1.1.1] - April 1st, 2020

- Added even more tests: full coverage!

## [1.1.0] - March 31st, 2020

- Added a bunch of tests to this package.
- Added GitHub Actions CI.
- Updated minium Flutter SDK to v1.10.

## [1.0.0] - January 24th, 2020

- Now this package is consider **STABLE**: no more breaking changes expected.
- Raised Dart SDK to v2.7.

## [0.1.0+1] - December 6th, 2019

- Updated documentation

## [0.1.0] - December 3rd, 2019

- First release!
