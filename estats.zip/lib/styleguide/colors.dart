import 'dart:ui';
import 'package:flutter/material.dart';

const Color mainBGColor                 = Color(0xFF004381);
const Color darkBGColor                 = Color(0xFF003260);
const Color placeHolderColor            = Color(0x66FFFFFF);
const Color greyColor                   = Color(0xFFDDE4EB);
const Color darkerGreyColor             = Color(0xFFBDC4CB);
const Color whiteColor                  = Color(0xFFFFFFFF);
const Color dangerColor                  = Color(0xFFF4072D);