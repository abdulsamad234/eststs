import 'dart:core';

class Player{
  bool isFootball;
  String firstName;
  String lastName;
  int number;

  Player({this.isFootball = true, this.firstName, this.lastName, this.number});
}